cd doc
export PYTHONPATH="$PYTHONPATH:../src"
make html
