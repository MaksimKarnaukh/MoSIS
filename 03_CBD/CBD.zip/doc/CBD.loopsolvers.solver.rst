CBD.loopsolvers.solver module
=============================

.. automodule:: CBD.loopsolvers.solver
    :members:
    :undoc-members:
    :show-inheritance:
