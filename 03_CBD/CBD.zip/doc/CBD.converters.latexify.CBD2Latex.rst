CBD.converters.latexify.CBD2Latex module
========================================

.. automodule:: CBD.converters.latexify.CBD2Latex
    :members:
    :undoc-members:
    :show-inheritance:
