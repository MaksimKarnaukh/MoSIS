pyCBD.preprocessing package
===========================

.. automodule:: pyCBD.preprocessing
    :members:
    :undoc-members:
    :show-inheritance:

Submodules
----------

.. toctree::

   pyCBD.preprocessing.butcher
   pyCBD.preprocessing.rungekutta

