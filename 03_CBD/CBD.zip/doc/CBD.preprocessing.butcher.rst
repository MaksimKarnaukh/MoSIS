CBD.preprocessing.butcher module
================================

.. automodule:: CBD.preprocessing.butcher
    :members:
    :undoc-members:
    :show-inheritance:
