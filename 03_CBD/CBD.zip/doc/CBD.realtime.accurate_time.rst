CBD.realtime.accurate_time module
=================================

.. automodule:: CBD.realtime.accurate_time
    :members:
    :undoc-members:
    :show-inheritance:
