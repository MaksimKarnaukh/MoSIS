Generate CBD Models from Equations
==================================

.. automodule:: pyCBD.converters.eq2CBD
    :members:
    :undoc-members:
    :show-inheritance:
