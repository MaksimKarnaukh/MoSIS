CBD.tracers.color module
========================

.. automodule:: CBD.tracers.color
    :members:
    :undoc-members:
    :show-inheritance:
