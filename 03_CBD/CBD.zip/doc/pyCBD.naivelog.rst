pyCBD.naivelog module
=====================

.. automodule:: pyCBD.naivelog
    :members:
    :undoc-members:
    :show-inheritance:
