pyCBD.preprocessing.butcher module
==================================

.. automodule:: pyCBD.preprocessing.butcher
    :members:
    :undoc-members:
    :show-inheritance:
