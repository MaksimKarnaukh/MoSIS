CBD.lib.endpoints module
========================

.. automodule:: CBD.lib.endpoints
    :members:
    :undoc-members:
    :show-inheritance:
