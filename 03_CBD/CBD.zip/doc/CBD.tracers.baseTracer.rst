CBD.tracers.baseTracer module
=============================

.. automodule:: CBD.tracers.baseTracer
    :members:
    :undoc-members:
    :show-inheritance:
