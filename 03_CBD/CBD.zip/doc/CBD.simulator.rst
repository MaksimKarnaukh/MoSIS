CBD.simulator module
====================

.. automodule:: CBD.simulator
    :members:
    :undoc-members:
    :show-inheritance:
