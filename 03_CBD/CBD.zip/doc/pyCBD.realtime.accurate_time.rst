pyCBD.realtime.accurate_time module
===================================

.. automodule:: pyCBD.realtime.accurate_time
    :members:
    :undoc-members:
    :show-inheritance:
