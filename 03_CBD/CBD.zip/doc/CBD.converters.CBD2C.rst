Generate C code from CBDs
=========================

This module has been extracted to the CBD2FMU generator project in order to minimize
code duplication and dependency overhead.
