pyCBD.scheduling module
=======================

.. automodule:: pyCBD.scheduling
    :members:
    :undoc-members:
    :show-inheritance:
