CBD.Core module
===============

.. automodule:: CBD.Core
    :members:
    :undoc-members:
    :show-inheritance:
