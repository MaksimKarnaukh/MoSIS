pyCBD.tracers.baseTracer module
===============================

.. automodule:: pyCBD.tracers.baseTracer
    :members:
    :undoc-members:
    :show-inheritance:
