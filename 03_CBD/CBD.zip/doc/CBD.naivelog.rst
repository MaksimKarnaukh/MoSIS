CBD.naivelog module
===================

.. automodule:: CBD.naivelog
    :members:
    :undoc-members:
    :show-inheritance:
