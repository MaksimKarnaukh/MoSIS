cd src  # Otherwise, the imports won't work (CBD is the root directory)
python3 -m unittest discover -v test "*.py"
#python -m unittest discover -v test "*.py"
